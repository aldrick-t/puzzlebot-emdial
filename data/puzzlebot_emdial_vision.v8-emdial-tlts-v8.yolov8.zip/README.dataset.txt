# puzzlebot_emdial_vision > Emdial-TLTS-V8
https://universe.roboflow.com/enceladus/puzzlebot_emdial_vision

Provided by a Roboflow user
License: CC BY 4.0

Vision training for a MCR2 Puzzlebot.
Running on a NVIDIA Jetson Nano.